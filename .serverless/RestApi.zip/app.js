const express = require('express')
const app = express();
const mongoose = require('./src/models/db')
const PORT =  process.env.PORT
// const movie = require('./models/movie')
app.use(express.json());
const movieService = require('./src/services/movieServices')
const routes = require('./routes')
app.use(express.json())
require('dotenv').config()

// 

// https://sbh1vvdygl.execute-api.us-east-1.amazonaws.com/dev/api/pranat/adidas

app.get('/pranat/adidas', (req,res) => {
    const data = {
        productName: "Galaxy 5",
        Productprice: 5000,
        productBrand: "adidas"
    }
    res.json({ response: data })
    res.status(200).json({ 'status': 'success', statusCode: 200, response: data })
})

app.use('/api', routes)

// app.listen(PORT,() => {
//     console.log(`Server is running on ${PORT}`);
// })

module.exports = app;